/*let caption = `*${comienzo}「 PELÍCULAS 」${fin}*\n
🔍 *Titulo: ${x.Title || ''}*
🗒️ *Año: ${x.Year || ''}*
⏱️ *Duración: ${x.Runtime || ''}*
📗 *Género: ${x.Genre || ''}*
👥 *Actores: ${x.Actors || ''}*

❕ Pedido por ${taguser}`
conn.fakeReply(m.chat, caption, '0@s.whatsapp.net', '*🔥 THE DORRAT - BOT 🔥*', 'status@broadcast')*/
