import fetch from "node-fetch";
let handler = async (m, {conn, usedPrefix, command}) => {
  let res = await fetch("https://api.waifu.pics/sfw/waifu");
  if (!res.ok) throw await res.text();
  let json = await res.json();
  if (!json.url) throw "Error!";
  conn.sendButton(m.chat, `𝙰-𝙰𝚁𝙰 𝙰𝚁𝙰 𝚂𝙴𝙼𝙿𝙰𝙸~~`, author, json.url, [["🔄 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔄", `/${command}`]], m);
};
handler.help = ["waifu"];
handler.tags = ["anime"];
handler.limit = 3;
handler.command = /^(waifu)$/i;
export default handler;
