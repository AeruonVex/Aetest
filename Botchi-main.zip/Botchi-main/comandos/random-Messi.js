import axios from "axios";
let handler = async (m, {conn, usedPrefix, command}) => {
  let res = (await axios.get(`https://raw.githubusercontent.com/DIEGO-OFC/DORRAT-BOT-MD/master/galeria/JSON/Messi.json`)).data;
  let url = await res[Math.floor(res.length * Math.random())];
  conn.sendButton(m.chat, "*Messi*", wm, url, [["⚽ SIGUIENTE ⚽", `${usedPrefix + command}`]], m);
};
handler.help = ["messi"];
handler.tags = ["internet"];
handler.command = /^(messi)$/i;
export default handler;
