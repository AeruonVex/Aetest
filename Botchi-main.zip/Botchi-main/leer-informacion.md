# DORR∆T-BOT-MD

Gracias por usar el bot. Si deseas volver a escanear el código QR, borra la carpeta DORRATSESSION o reinicia el bot con el comando "restart" o "start".

- Número del bot oficial: +573122695406
- Si deseas cambiar los números owners, ve a configuracion.js
- Creador: DIEGO-OFC número: +593959425714
- Si tienes errores en la consola, repórtalos al número +593959425714
- Puedes editar el bot como desees.
- Host recomendados: boxmineworld.com o Termux.
- Si necesitas ayuda o soporte, únete al grupo oficial o escribe al número del creador.
- En este GitHub siempre tendrás actualizaciones.
- No me hago responsable del mal uso que puedas darle al bot.
- Los números del bot oficial son: wa.me/573122695406 o wa.me/240555351060
- Bot creado para la diversión de los usuarios.
**DORR∆T-BOT-MD CREATE BY DIEGO-OFC**
### Grupo oficial
Únete al grupo oficial para obtener ayuda:
https://chat.whatsapp.com/CrsOmirjZNYKrvnQNT98Oo
Gracias por leer.
**—◉ 𝚃𝚄𝚃𝙾𝚁𝙸𝙰𝙻 𝚃𝙴𝚁𝙼𝚄𝚇:**
https://youtu.be/DKo7PO2ta4o
**—◉ 𝙲𝙾𝙼𝙰𝙽𝙳𝙾𝚂 𝚃𝙴𝚁𝙼𝚄𝚇**
```bash
cd
termux-setup-storage
apt update 
pkg upgrade 
pkg install git -y
pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
pkg install yarn
git clone https://github.com/DIEGO-OFC/DORRAT-TERMUX
cd DORRAT-TERMUX 
npm install 
yarn install 
npm install
npm update
npm start
```
**Cómo cambió el bot sin perder los diamantes y xp?**
Descarga la database.json y instala el nuevo bot, antes de encerderlo pones la database
