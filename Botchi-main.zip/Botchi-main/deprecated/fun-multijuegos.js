//let com = `${usedPrefix}`
//let juegos = `${pickRandom([`${com}formarareja`,`${com}reto`,`${com}verdad`])}`

//let handler = async (m, { conn, usedPrefix, usedPrefix: _p, __dirname, text }) => {
