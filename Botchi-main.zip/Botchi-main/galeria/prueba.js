const prueba = `gola`
const dorrat = [prueba]

export default dorrat;
function pickRandom(list) {
return list[Math.floor(list.length * Math.random())]}
