let media = "./Menu2.jpg";
let handler = async (m, {conn}) =>
  conn.sendButton(
    m.chat,
    `
*𝙷𝙾𝙻𝙰 𝚄𝚂𝚄𝙰𝚁𝙸𝙾 👋🏻, 𝚃𝙴 𝙸𝙽𝚅𝙸𝚃𝙾 𝙰 𝚄𝙽𝙸𝚁𝚃𝙴 𝙰 𝙻𝙾𝚂 𝙶𝚁𝚄𝙿𝙾𝚂 𝙾𝙵𝙸𝙲𝙸𝙰𝙻𝙴𝚂 𝙳𝙴 †𝐃⃟𝕺𝐑⃯𝐑𝐇⃯𝚵𝐓᪣𝕭⃯𝚹⃯𝐓⃤ 𝙿𝙰𝚁𝙰 𝙲𝙾𝙽𝚅𝙸𝚅𝙸𝚁 𝙲𝙾𝙽 𝙻𝙰 𝙲𝙾𝙼𝚄𝙽𝙸𝙳𝙰𝙳 :D*

╭━━❍𝐓𝐇𝐄-𝐃𝐎𝐑𝐑𝐀𝐓-𝐁𝐎𝐓-𝐌𝐃❍━━╮
┃ ╭━━━━━━━━━━━━━━━━╮
┃ ┃ ╭┈────────────╮
┃ ┃ │❍ 𝐆𝐑𝐔𝐏𝐎𝐒-𝐎𝐅𝐈𝐂𝐈𝐀𝐋𝐄𝐒 ❍
┃ ┃ ╰┈────────────╯
┃ ╰━━━━━━━━━━━━━━━━╯
╰━━━𝐆𝐑𝐔𝐏𝐎𝐒-𝐎𝐅𝐈𝐂𝐈𝐀𝐋𝐄𝐒╾━━━╯

╭┈───────────────╮
│ ▻ 𝙶𝚁𝚄𝙿𝙾 𝙳𝙴 𝙰𝙲𝚃𝚄𝙰𝙻𝙸𝚉𝙰𝙲𝙸𝙾𝙽𝙴𝚂 ◅
╰┈───────────────╯
╭━━━━━━━━━━━━━━━━━━━
┃⇛ https://chat.whatsapp.com/Gt8tzfxKFl15bqIAjxmqIe ⇚
╰━━━━━━━━━━━━━━━━━━━╯

╭━━━━━━━━━━━━━━━━━━━╾•
┃1: ${md} ⇚
┃2: https://chat.whatsapp.com/C3TfpGAEnpYHMqfe5YbZfc ⇚
┃3: https://chat.whatsapp.com/Gc802vnpuQYFaTfvDrk9yw ⇚
┃4: https://chat.whatsapp.com/Fs2jKmoWBTT00oPSFVMZJC ⇚
┃5: https://chat.whatsapp.com/FfxAsnshsAB4vQ1sGIPBlj ⇚
┃6: https://chat.whatsapp.com/CquA3pNNwFr9b7OMDMuNlw ⇚
╰━━━━━━━━━━━━━━━━━━━━━╯

╭━━━━━━━━━━━━━━━━━━━╾•
┃ ➢ 𝐺𝑅𝑈𝑃𝑂 𝐷𝐸 𝑀𝐼𝑁𝐸𝐶𝑅𝐴𝐹𝑇 
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━━━━━━━━━━━━━━━━━━╾
┃ https://chat.whatsapp.com/HNayAS8WrE1EtThLpkllRS
╰━━━━━━━━━━━━━━━━━━━━╯
`.trim(),
    wm,
    media,
    [["💟 𝙼𝙴𝙽𝚄 𝙿𝚁𝙸𝙽𝙲𝙸𝙿𝙰𝙻 💟", "#menu"]],
    m
  );
handler.command = /^linkgc|grupos$/i;
export default handler;
