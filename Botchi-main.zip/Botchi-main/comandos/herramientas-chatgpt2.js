/*-------------------------------------------------------*/
/* [❗]                      [❗]                      [❗] */
/*                                                       */
/*         |- [ ⚠ ] - CODIGO OFUSCADO - [ ⚠ ] -|        */
/*     —◉ DESAROLLADO POR OTOSAKA:                       */
/*     ◉ Otosaka (https://github.com/6otosaka9)          */
/*     ◉ Número: wa.me/51993966345                       */
/*                                                       */
/*     —◉ FT:                                            */
/*     ◉ BrunoSobrino (https://github.com/BrunoSobrino)  */
/*                                                       */
/* [❗]                      [❗]                      [❗] */
/*-------------------------------------------------------*/
const _0x40c539 = _0x22b2;
(function (_0x2cc3b9, _0x44cc20) {
  const _0x19eda3 = _0x22b2,
    _0x4fc303 = _0x2cc3b9();
  while (!![]) {
    try {
      const _0x354613 =
        (parseInt(_0x19eda3(0x16e)) / 0x1) * (parseInt(_0x19eda3(0x17d)) / 0x2) +
        parseInt(_0x19eda3(0x184)) / 0x3 +
        -parseInt(_0x19eda3(0x162)) / 0x4 +
        (parseInt(_0x19eda3(0x170)) / 0x5) * (-parseInt(_0x19eda3(0x166)) / 0x6) +
        parseInt(_0x19eda3(0x18a)) / 0x7 +
        (-parseInt(_0x19eda3(0x179)) / 0x8) * (-parseInt(_0x19eda3(0x17c)) / 0x9) +
        (-parseInt(_0x19eda3(0x181)) / 0xa) * (parseInt(_0x19eda3(0x164)) / 0xb);
      if (_0x354613 === _0x44cc20) break;
      else _0x4fc303["push"](_0x4fc303["shift"]());
    } catch (_0x448c3d) {
      _0x4fc303["push"](_0x4fc303["shift"]());
    }
  }
})(_0x2937, 0x25618);
function _0x22b2(_0x281ee0, _0x1e2692) {
  const _0x2937e3 = _0x2937();
  return (
    (_0x22b2 = function (_0x22b2ba, _0x23b7b3) {
      _0x22b2ba = _0x22b2ba - 0x162;
      let _0x5eb17e = _0x2937e3[_0x22b2ba];
      return _0x5eb17e;
    }),
    _0x22b2(_0x281ee0, _0x1e2692)
  );
}
function _0x2937() {
  const _0x4e1ab7 = [
    "https://api.lolhuman.xyz/api/openai?apikey=",
    "ia2",
    "338142heWRst",
    "chatgpt",
    "assistant",
    "command",
    "\x20Codigo\x20en\x20JS\x20para\x20un\x20juego\x20de\x20cartas*",
    "log",
    "&apikey=tamvan",
    "push",
    "Human:",
    "openai_key",
    "post",
    "*[❗]\x20𝙴𝚁𝚁𝙾𝚁,\x20𝚅𝚄𝙴𝙻𝚅𝙰\x20𝙰\x20𝙸𝙽𝚃𝙴𝙽𝚃𝙰𝚁𝙻𝙾*",
    "10964UpDJpc",
    "message",
    "22nukLMs",
    "application/json",
    "6zgPxwQ",
    "choices",
    "&user=user-unique-id",
    "chat",
    "createCompletion",
    "text",
    "https://telegra.ph/file/10e013d9ae4d9cdf5af14.jpg",
    "Bearer\x20",
    "1CkhFEB",
    "stringify",
    "1412230jqdheN",
    "system",
    "*[❗]\x20𝙸𝙽𝙶𝚁𝙴𝚂𝙴\x20𝚄𝙽𝙰\x20𝙿𝙴𝚃𝙸𝙲𝙸𝙾𝙽\x20𝙾\x20𝚄𝙽𝙰\x20𝙾𝚁𝙳𝙴𝙽\x20𝙿𝙰𝚁𝙰\x20𝚄𝚂𝙰𝚁\x20𝙻𝙰\x20𝙵𝚄𝙽𝙲𝙸𝙾𝙽\x20𝙳𝙴\x20𝙲𝙷𝙰𝚃𝙶𝙿𝚃*\x0a\x0a*—◉\x20𝙴𝙹𝙴𝙼𝙿𝙻𝙾𝚂\x20𝙳𝙴\x20𝙿𝙴𝚃𝙸𝙲𝙸𝙾𝙽𝙴𝚂\x20𝚈\x20𝙾𝚁𝙳𝙴𝙽𝙴𝚂*\x0a*◉\x20",
    "openai2",
    "&text=",
    "data",
    "https://api.openai.com/v1/chat/completions",
    "trim",
    "TOOLS\x20-\x20CHATGPT\x202",
    "2376YkXUNi",
    "chatgpt2",
    "\x20Reflexion\x20sobre\x20la\x20serie\x20Merlina\x202022\x20de\x20netflix*\x0a*◉\x20",
    "1791mgrPSh",
    "307246kIsRPV",
    "gpt-3.5-turbo",
    "result",
    "sender",
    "487390VXHcdy",
    "users",
    "sendMessage",
    "824235uMnLsl",
    "http://paypal.me/DorratBotOficial",
    "content",
    "json",
  ];
  _0x2937 = function () {
    return _0x4e1ab7;
  };
  return _0x2937();
}
import _0x546a50 from "node-fetch";
import _0x572fdb from "axios";
import {Configuration, OpenAIApi} from "openai";
const configuration = new Configuration({organization: global["openai_org_id"], apiKey: global[_0x40c539(0x193)]}),
  openaiii = new OpenAIApi(configuration);
let handler = async (_0x339b78, {conn: _0x4ece40, text: _0x4e90bc, usedPrefix: _0x5ef99f, command: _0x568741}) => {
  const _0x56cc6b = _0x40c539;
  if (!_0x4e90bc) throw _0x56cc6b(0x172) + (_0x5ef99f + _0x568741) + _0x56cc6b(0x17b) + (_0x5ef99f + _0x568741) + _0x56cc6b(0x18e);
  try {
    let _0x11d0ae = global[_0x56cc6b(0x18b)][_0x56cc6b(0x175)][_0x56cc6b(0x182)][_0x339b78[_0x56cc6b(0x180)]];
    _0x11d0ae["push"]({role: "user", content: _0x4e90bc});
    const _0x35c77c = {
      method: _0x56cc6b(0x194),
      url: _0x56cc6b(0x176),
      headers: {"Content-Type": _0x56cc6b(0x165), Authorization: _0x56cc6b(0x16d) + global[_0x56cc6b(0x193)]},
      data: JSON[_0x56cc6b(0x16f)]({model: _0x56cc6b(0x17e), messages: [{role: _0x56cc6b(0x171), content: ""}, ..._0x11d0ae]}),
    };
    let _0x3e04db = await _0x572fdb(_0x35c77c);
    _0x11d0ae[_0x56cc6b(0x191)]({
      role: _0x56cc6b(0x18c),
      content: _0x3e04db[_0x56cc6b(0x175)][_0x56cc6b(0x167)][0x0][_0x56cc6b(0x163)][_0x56cc6b(0x186)],
    }),
      _0x4ece40[_0x56cc6b(0x183)](
        _0x339b78[_0x56cc6b(0x169)],
        {
          image: {url: _0x56cc6b(0x16c)},
          caption: _0x3e04db[_0x56cc6b(0x175)]["choices"][0x0][_0x56cc6b(0x163)][_0x56cc6b(0x186)],
          contextInfo: {
            mentionedJid: [_0x339b78[_0x56cc6b(0x180)]],
            externalAdReply: {
              title: _0x56cc6b(0x178),
              sourceUrl: _0x56cc6b(0x185),
              mediaType: 0x1,
              showAdAttribution: !![],
              thumbnailUrl: _0x56cc6b(0x16c),
            },
          },
        },
        {quoted: _0x339b78}
      );
  } catch (_0x385b7b) {
    console[_0x56cc6b(0x18f)](_0x385b7b);
    try {
      const _0x2f2495 = await openaiii[_0x56cc6b(0x16a)]({
        model: "text-davinci-003",
        prompt: _0x4e90bc,
        temperature: 0.3,
        max_tokens: 0x1001,
        stop: ["Ai:", _0x56cc6b(0x192)],
        top_p: 0x1,
        frequency_penalty: 0.2,
        presence_penalty: 0x0,
      });
      _0x4ece40[_0x56cc6b(0x183)](
        _0x339b78[_0x56cc6b(0x169)],
        {
          image: {url: _0x56cc6b(0x16c)},
          caption: _0x2f2495[_0x56cc6b(0x175)]["choices"][0x0][_0x56cc6b(0x16b)][_0x56cc6b(0x177)](),
          contextInfo: {
            mentionedJid: [_0x339b78[_0x56cc6b(0x180)]],
            externalAdReply: {
              title: _0x56cc6b(0x178),
              sourceUrl: "http://paypal.me/DorratBotOficial",
              mediaType: 0x1,
              showAdAttribution: !![],
              thumbnailUrl: _0x56cc6b(0x16c),
            },
          },
        },
        {quoted: _0x339b78}
      );
    } catch (_0x4d1851) {
      console[_0x56cc6b(0x18f)](_0x4d1851);
      try {
        let _0x764006 = await _0x546a50("https://api.ibeng.tech/api/info/openai?text=" + _0x4e90bc + _0x56cc6b(0x190)),
          _0x5b81c6 = await _0x764006[_0x56cc6b(0x187)]();
        _0x4ece40[_0x56cc6b(0x183)](
          _0x339b78["chat"],
          {
            image: {url: _0x56cc6b(0x16c)},
            caption: _0x5b81c6[_0x56cc6b(0x175)][_0x56cc6b(0x175)][_0x56cc6b(0x177)](),
            contextInfo: {
              mentionedJid: [_0x339b78["sender"]],
              externalAdReply: {
                title: _0x56cc6b(0x178),
                sourceUrl: _0x56cc6b(0x185),
                mediaType: 0x1,
                showAdAttribution: !![],
                thumbnailUrl: _0x56cc6b(0x16c),
              },
            },
          },
          {quoted: _0x339b78}
        );
      } catch (_0x407250) {
        console[_0x56cc6b(0x18f)](_0x407250);
        try {
          let _0x36eae1 = await _0x546a50(_0x56cc6b(0x188) + lolkeysapi + _0x56cc6b(0x174) + _0x4e90bc + _0x56cc6b(0x168)),
            _0x780df1 = await _0x36eae1["json"]();
          _0x4ece40["sendMessage"](
            _0x339b78[_0x56cc6b(0x169)],
            {
              image: {url: _0x56cc6b(0x16c)},
              caption: ("" + _0x780df1[_0x56cc6b(0x17f)])[_0x56cc6b(0x177)](),
              contextInfo: {
                mentionedJid: [_0x339b78["sender"]],
                externalAdReply: {
                  title: _0x56cc6b(0x178),
                  sourceUrl: _0x56cc6b(0x185),
                  mediaType: 0x1,
                  showAdAttribution: !![],
                  thumbnailUrl: _0x56cc6b(0x16c),
                },
              },
            },
            {quoted: _0x339b78}
          );
        } catch (_0x5d4930) {
          console[_0x56cc6b(0x18f)](_0x5d4930);
          throw _0x56cc6b(0x195);
        }
      }
    }
  }
};
handler[_0x40c539(0x18d)] = [_0x40c539(0x173), _0x40c539(0x17a), _0x40c539(0x189), "robot2"];
export default handler;
