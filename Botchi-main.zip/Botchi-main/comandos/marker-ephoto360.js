/*
- Obten mas efectos en https://violetics.pw/api/ephoto360
- Usa la apikey "beta"
*/
let handler = async (m, {conn, args, command, usedPrefix}) => {
  let response = args.join(" ").split("|");
  if (!args[0]) throw "*[❗] 𝙸𝙽𝙶𝚁𝙴𝚂𝙴 𝚄𝙽 𝚃𝙴𝚇𝚃𝙾*";
  if (command == "logocorazon") {
    try {
      await conn.reply(m.chat, "*[❗] 𝙴𝙻𝙰𝙱𝙾𝚁𝙰𝙽𝙳𝙾 𝚂𝚄 𝙳𝙸𝚂𝙴𝙽̃𝙾, 𝙴𝚂𝙿𝙴𝚁𝙴 𝚄𝙽 𝙼𝙾𝙼𝙴𝙽𝚃𝙾...*", m);
      let res = `https://violetics.pw/api/ephoto360/heart-flashlight?apikey=beta&text=${response[0]}`;
      await conn.sendFile(m.chat, res, "error.jpg", null, m);
    } catch {
      await conn.reply(m.chat, "*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝚁𝚁𝙾𝚁, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚅𝚄𝙴𝙻𝚅𝙰 𝙰 𝙸𝙽𝚃𝙴𝙽𝚃𝙰𝚁𝙻𝙾*", m);
    }
  }
  if (command == "logochristmas") {
    try {
      await conn.reply(m.chat, "*[❗] 𝙴𝙻𝙰𝙱𝙾𝚁𝙰𝙽𝙳𝙾 𝚂𝚄 𝙳𝙸𝚂𝙴𝙽̃𝙾, 𝙴𝚂𝙿𝙴𝚁𝙴 𝚄𝙽 𝙼𝙾𝙼𝙴𝙽𝚃𝙾...*", m);
      let res = `https://violetics.pw/api/ephoto360/christmas-snow?apikey=beta&text=${response[0]}`;
      await conn.sendFile(m.chat, res, "error.jpg", null, m);
    } catch {
      await conn.reply(m.chat, "*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝚁𝚁𝙾𝚁, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚅𝚄𝙴𝙻𝚅𝙰 𝙰 𝙸𝙽𝚃𝙴𝙽𝚃𝙰𝚁𝙻𝙾*", m);
    }
  }
  if (command == "mensajefalso") {
    if (!response[1]) throw `*[❗] 𝙸𝙽𝙶𝚁𝙴𝚂𝙴 𝚄𝙽 𝚂𝙴𝙶𝚄𝙽𝙳𝙾 𝚃𝙴𝚇𝚃𝙾, 𝙴𝙹𝙴𝙼𝙿𝙻𝙾 ${usedPrefix + command} MysticBot|Hola como puedo ayudarte?*`;
    await conn.reply(m.chat, "*[❗] 𝙴𝙻𝙰𝙱𝙾𝚁𝙰𝙽𝙳𝙾 𝚂𝚄 𝙳𝙸𝚂𝙴𝙽̃𝙾, 𝙴𝚂𝙿𝙴𝚁𝙴 𝚄𝙽 𝙼𝙾𝙼𝙴𝙽𝚃𝙾...*", m);
    try {
      let res = `https://api-anubiskun.herokuapp.com/api/fakewa?name=${response[0]}&pesan=${response[1]}`;
      await conn.sendFile(m.chat, res, "error.jpg", null, m);
    } catch {
      await conn.reply(m.chat, "*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝚁𝚁𝙾𝚁, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚅𝚄𝙴𝙻𝚅𝙰 𝙰 𝙸𝙽𝚃𝙴𝙽𝚃𝙰𝚁𝙻𝙾*", m);
    }
  }
};
handler.command = /^mensajefalso|logocorazon|logochristmas/i;
export default handler;
