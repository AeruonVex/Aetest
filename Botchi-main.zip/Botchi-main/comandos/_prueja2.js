
import dorrat from './galeria/prueba.js'

let handler = async (m, {text, command, conn}) => {

let sexo = await dorrat

m.reply(sexo)

}
handler.command = ["prueba3"];
export default handler;
