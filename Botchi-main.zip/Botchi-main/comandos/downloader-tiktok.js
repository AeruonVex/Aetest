import fetch from "node-fetch";
import {generateWAMessageFromContent} from "@adiwajshing/baileys";
import {tiktokdl, tiktokdlv2} from "@bochilteam/scraper";
let handler = async (m, {conn, text, usedPrefix, command, args}) => {
  if (!text)
    throw `*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝙽𝙻𝙰𝙲𝙴 𝙳𝙴 𝚃𝙸𝙺𝚃𝙾𝙺 𝙵𝙰𝙻𝚃𝙰𝙽𝚃𝙴, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝙸𝙽𝙶𝚁𝙴𝚂𝙴 𝙴𝙽 𝙴𝙽𝙻𝙰𝙲𝙴/𝙻𝙸𝙽𝙺 𝙳𝙴 𝙰𝙻𝙶𝚄𝙽 𝚅𝙸𝙳𝙴𝙾 𝙳𝙴 𝚃𝙸𝙺𝚃𝙾𝙺*\n\n*—◉ 𝙴𝙹𝙴𝙼𝙿𝙻𝙾:*\n*${
      usedPrefix + command
    } https://vm.tiktok.com/ZML42vSnn/*`;
  if (!/(?:https:?\/{2})?(?:w{3}|vm|vt|t)?\.?tiktok.com\/([^\s&]+)/gi.test(text))
    throw `*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝙽𝙻𝙰𝙲𝙴 𝙳𝙴 𝚃𝙸𝙺𝚃𝙾𝙺 𝙸𝙽𝙲𝙾𝚁𝚁𝙴𝙲𝚃𝙾, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝙸𝙽𝙶𝚁𝙴𝚂𝙴 𝙴𝙽 𝙴𝙽𝙻𝙰𝙲𝙴/𝙻𝙸𝙽𝙺 𝙳𝙴 𝙰𝙻𝙶𝚄𝙽 𝚅𝙸𝙳𝙴𝙾 𝙳𝙴 𝚃𝙸𝙺𝚃𝙾𝙺*\n\n*—◉ 𝙴𝙹𝙴𝙼𝙿𝙻𝙾:*\n*${
      usedPrefix + command
    } https://vm.tiktok.com/ZML42vSnn/*`;
  let texto = `*[❗] @${m.sender.split`@`[0]} 𝙰𝙶𝚄𝙰𝚁𝙳𝙴 𝚄𝙽 𝙼𝙾𝙼𝙴𝙽𝚃𝙾 𝙴𝙽 𝙻𝙾 𝚀𝚄𝙴 𝙴𝙽𝚅𝙸𝙾 𝚂𝚄 𝚅𝙸𝙳𝙴𝙾 𝙳𝙴 𝚃𝙸𝙺𝚃𝙾𝙺*`;
  try {
    let prep = generateWAMessageFromContent(
      m.chat,
      {
        extendedTextMessage: {
          text: texto,
          contextInfo: {
            externalAdReply: {title: "𝐃⃟𝕺𝐑⃯𝐑𝐇⃯𝚵𝐓᪣𝕭⃯𝚹⃯𝐓⃤", body: null, thumbnail: imagen1, sourceUrl: "https://github.com/DIEGO-OFC/DORRAT-BOT-MD"},
            mentionedJid: [m.sender],
          },
        },
      },
      {quoted: m}
    );
    let url = (await fetch(text)).url;
    let res = await (await fetch(`https://api2.musical.ly/aweme/v1/aweme/detail/?aweme_id=${url.split("?")[0].split("/")[5]}`)).json();
    let data = res.aweme_detail.video.play_addr.url_list;
    let meta = await getInfo(url).catch((_) => {});
    await conn.relayMessage(m.chat, prep.message, {messageId: prep.key.id, mentions: [m.sender]});
    let buttons = [{buttonText: {displayText: "𝙰𝚄𝙳𝙸𝙾"}, buttonId: `${usedPrefix}tomp3`}];
    conn.sendMessage(
      m.chat,
      {video: {url: data[data.length - 1]}, caption: "_𝐃⃟𝕺𝐑⃯𝐑𝐇⃯𝚵𝐓᪣𝕭⃯𝚹⃯𝐓⃤_", footer: await shortUrl(data[data.length - 1]), buttons},
      {quoted: m}
    );
  } catch {
    try {
      let prep = generateWAMessageFromContent(
        m.chat,
        {
          extendedTextMessage: {
            text: texto,
            contextInfo: {
              externalAdReply: {title: "𝐃⃟𝕺𝐑⃯𝐑𝐇⃯𝚵𝐓᪣𝕭⃯𝚹⃯𝐓⃤", body: null, thumbnail: imagen1, sourceUrl: "https://github.com/DIEGO-OFC/DORRAT-BOT-MD"},
              mentionedJid: [m.sender],
            },
          },
        },
        {quoted: m}
      );
      const {
        author: {nickname},
        video,
        description,
      } = await tiktokdl(args[0]).catch(async (_) => await tiktokdlv2(args[0]));
      const url = video.no_watermark_raw || video.no_watermark || video.no_watermark_hd || video.with_watermark;
      await conn.relayMessage(m.chat, prep.message, {messageId: prep.key.id, mentions: [m.sender]});
      let buttons = [{buttonText: {displayText: "𝙰𝚄𝙳𝙸𝙾"}, buttonId: `${usedPrefix}tomp3`}];
      conn.sendMessage(m.chat, {video: {url: url}, caption: "_𝐃⃟𝕺𝐑⃯𝐑𝐇⃯𝚵𝐓᪣𝕭⃯𝚹⃯𝐓⃤_", footer: await shortUrl(url), buttons}, {quoted: m});
    } catch {
      await m.reply("*[❗𝐈𝐍𝐅𝐎❗] 𝙻𝙾 𝙻𝙰𝙼𝙴𝙽𝚃𝙾, 𝙾𝙲𝚄𝚁𝚁𝙸𝙾 𝚄𝙽 𝙴𝚁𝚁𝙾𝚁 𝙰𝙻 𝙳𝙴𝚂𝙲𝙰𝚁𝙶𝙰𝚁 𝚂𝚄 𝚅𝙸𝙳𝙴𝙾, 𝙿𝙾𝚁 𝙵𝙰𝚅𝙾𝚁 𝚅𝚄𝙴𝙻𝚅𝙰 𝙰 𝙸𝙽𝚃𝙴𝙽𝚃𝙰𝚁𝙻𝙾*");
    }
  }
};
handler.help = ["tiktok"];
handler.tags = ["downloader"];
handler.alias = ["tiktok", "tikdl", "tiktokdl", "tiktoknowm"];
handler.command = /^(tt|tiktok)(dl|nowm)?$/i;
export default handler;

async function getInfo(url) {
  let id = url.split("?")[0].split("/");
  let res = await (await fetch(`https://www.tiktok.com/node/share/video/${id[3]}/${id[5]}/`)).json();
  return res?.seoProps?.metaParams;
}
async function shortUrl(url) {
  return await (await fetch(`https://tinyurl.com/api-create.php?url=${url}`)).text();
}
